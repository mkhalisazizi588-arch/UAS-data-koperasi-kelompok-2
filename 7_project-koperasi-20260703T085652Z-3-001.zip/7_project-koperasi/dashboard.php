<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Sistem Koperasi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="app-layout">

    <aside class="sidebar">
        <div class="logo">
            <div class="logo-box">K</div>
            <div>
                <h4>KoperasiApp</h4>
                <small>Panel Administrator</small>
            </div>
        </div>

        <div class="menu-label">Menu Utama</div>
        <ul class="nav-menu">
            <li><a href="dashboard.php" class="active">🏠 Dashboard</a></li>
            <li><a href="anggota.php">👥 Data Anggota</a></li>
            <li><a href="simpanan.php">💰 Input Simpanan</a></li>
            <li><a href="laporan.php">📊 Laporan Simpanan</a></li>
        </ul>

        <div class="menu-label">Akun</div>
        <ul class="nav-menu">
            <li><a href="#">🚪 Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="topbar">
            <div>
                <h2>Dashboard Koperasi</h2>
                <p>Ringkasan data anggota dan simpanan koperasi.</p>
            </div>
            <div class="user-pill">Administrator</div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-soft-primary">👥</div>
                    <h3>125</h3>
                    <p>Total Anggota</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-soft-blue">💳</div>
                    <h3>Rp 12,5 Jt</h3>
                    <p>Simpanan Pokok</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-soft-yellow">📌</div>
                    <h3>Rp 8,7 Jt</h3>
                    <p>Simpanan Wajib</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-soft-red">💰</div>
                    <h3>Rp 20,4 Jt</h3>
                    <p>Total Simpanan</p>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-8">
                <div class="content-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Transaksi Simpanan Terbaru</h5>
                        <a href="simpanan.html" class="btn btn-sm btn-primary">Input Simpanan</a>
                    </div>

                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Anggota</th>
                                        <th>Tanggal</th>
                                        <th>Jenis</th>
                                        <th>Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td><span class="avatar">AF</span>Ahmad Fauzi</td>
                                        <td>01 Juli 2026</td>
                                        <td><span class="badge-soft badge-pokok">Pokok</span></td>
                                        <td class="money">Rp 100.000</td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td><span class="avatar">SR</span>Siti Rahmah</td>
                                        <td>01 Juli 2026</td>
                                        <td><span class="badge-soft badge-sukarela">Sukarela</span></td>
                                        <td class="money">Rp 150.000</td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td><span class="avatar">MI</span>M. Ikhsan</td>
                                        <td>01 Juli 2026</td>
                                        <td><span class="badge-soft badge-wajib">Wajib</span></td>
                                        <td class="money">Rp 50.000</td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td><span class="avatar">NA</span>Nur Aisyah</td>
                                        <td>01 Juli 2026</td>
                                        <td><span class="badge-soft badge-pokok">Pokok</span></td>
                                        <td class="money">Rp 100.000</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="content-card">
                    <div class="card-header">
                        <h5>Ringkasan Koperasi</h5>
                    </div>

                    <div class="card-body">
                        <div class="summary-box mb-3">
                            <div class="d-flex justify-content-between">
                                <span>Anggota Aktif</span>
                                <strong>118</strong>
                            </div>
                        </div>

                        <div class="summary-box mb-3">
                            <div class="d-flex justify-content-between">
                                <span>Anggota Nonaktif</span>
                                <strong>7</strong>
                            </div>
                        </div>

                        <div class="summary-box mb-3">
                            <div class="d-flex justify-content-between">
                                <span>Transaksi Bulan Ini</span>
                                <strong>56</strong>
                            </div>
                        </div>

                        <div class="summary-box">
                            <div class="d-flex justify-content-between">
                                <span>Total Saldo Simpanan</span>
                                <strong>Rp 20.450.000</strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </main>

</div>

</body>
</html>