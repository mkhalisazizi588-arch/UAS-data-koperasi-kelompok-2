<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Simpanan | Sistem Koperasi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="app-layout">
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-box">K</div>
            <div>
                <h4>KoperasiApp</h4>
                <small>Panel Administrator</small>
            </div>
        </div>

        <div class="menu-label">Menu Utama</div>
        <ul class="nav-menu">
            <li><a href="dashboard.php" class="active">🏠 Dashboard</a></li>
            <li><a href="anggota.php">👥 Data Anggota</a></li>
            <li><a href="simpanan.php">💰 Input Simpanan</a></li>
            <li><a href="laporan.php">📊 Laporan Simpanan</a></li>
        </ul>

        <div class="menu-label">Akun</div>
        <ul class="nav-menu">
            <li><a href="#">🚪 Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">

        <div class="topbar">
            <div>
                <h2>Laporan Simpanan</h2>
                <p>Rekap total simpanan pokok, wajib, sukarela, dan total saldo anggota.</p>
            </div>
            <div class="user-pill">Administrator</div>
        </div>

        <div class="content-card mb-4">
            <div class="card-header">
                <h5>Filter Laporan</h5>
            </div>

            <div class="card-body">
                <form action="#" method="get">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Tanggal Mulai</label>
                            <input type="date" class="form-control" value="2026-07-01">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Tanggal Selesai</label>
                            <input type="date" class="form-control" value="2026-07-31">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Status Anggota</label>
                            <select class="form-select">
                                <option>Semua Status</option>
                                <option>Aktif</option>
                                <option>Nonaktif</option>
                            </select>
                        </div>

                        <div class="col-md-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                Tampilkan
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-soft-primary">👥</div>
                    <h3>125</h3>
                    <p>Total Anggota</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-soft-blue">💳</div>
                    <h3>Rp 12,5 Jt</h3>
                    <p>Total Pokok</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-soft-yellow">📌</div>
                    <h3>Rp 8,7 Jt</h3>
                    <p>Total Wajib</p>
                </div>
            </div>

            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-icon bg-soft-red">💰</div>
                    <h3>Rp 20,4 Jt</h3>
                    <p>Total Saldo</p>
                </div>
            </div>
        </div>

        <div class="content-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5>Tabel Laporan Simpanan</h5>
                <a href="#" class="btn btn-sm btn-outline-primary">Cetak Laporan</a>
            </div>

            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>No. Anggota</th>
                                <th>Nama Anggota</th>
                                <th>Simpanan Pokok</th>
                                <th>Simpanan Wajib</th>
                                <th>Simpanan Sukarela</th>
                                <th>Total Simpanan</th>
                                <th>Status</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>KOP-2026-001</td>
                                <td>Ahmad Fauzi</td>
                                <td class="money">Rp 100.000</td>
                                <td class="money">Rp 50.000</td>
                                <td class="money">Rp 0</td>
                                <td class="money">Rp 150.000</td>
                                <td><span class="badge-soft badge-aktif">Aktif</span></td>
                            </tr>

                            <tr>
                                <td>2</td>
                                <td>KOP-2026-002</td>
                                <td>Siti Rahmah</td>
                                <td class="money">Rp 100.000</td>
                                <td class="money">Rp 0</td>
                                <td class="money">Rp 150.000</td>
                                <td class="money">Rp 250.000</td>
                                <td><span class="badge-soft badge-aktif">Aktif</span></td>
                            </tr>

                            <tr>
                                <td>3</td>
                                <td>KOP-2026-003</td>
                                <td>M. Ikhsan</td>
                                <td class="money">Rp 0</td>
                                <td class="money">Rp 50.000</td>
                                <td class="money">Rp 0</td>
                                <td class="money">Rp 50.000</td>
                                <td><span class="badge-soft badge-aktif">Aktif</span></td>
                            </tr>

                            <tr>
                                <td>4</td>
                                <td>KOP-2026-004</td>
                                <td>Nur Aisyah</td>
                                <td class="money">Rp 100.000</td>
                                <td class="money">Rp 0</td>
                                <td class="money">Rp 0</td>
                                <td class="money">Rp 100.000</td>
                                <td><span class="badge-soft badge-aktif">Aktif</span></td>
                            </tr>

                            <tr>
                                <td>5</td>
                                <td>KOP-2026-005</td>
                                <td>Rizky Maulana</td>
                                <td class="money">Rp 0</td>
                                <td class="money">Rp 0</td>
                                <td class="money">Rp 200.000</td>
                                <td class="money">Rp 200.000</td>
                                <td><span class="badge-soft badge-nonaktif">Nonaktif</span></td>
                            </tr>
                        </tbody>

                        <tfoot>
                            <tr>
                                <th colspan="3">Total Keseluruhan</th>
                                <th class="money">Rp 300.000</th>
                                <th class="money">Rp 100.000</th>
                                <th class="money">Rp 350.000</th>
                                <th class="money">Rp 750.000</th>
                                <th></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

    </main>

</div>

</body>
</html>