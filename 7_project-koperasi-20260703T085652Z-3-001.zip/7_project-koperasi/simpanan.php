<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Simpanan | Sistem Koperasi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="app-layout">

    <aside class="sidebar">
        <div class="logo">
            <div class="logo-box">K</div>
            <div>
                <h4>KoperasiApp</h4>
                <small>Panel Administrator</small>
            </div>
        </div>

        <div class="menu-label">Menu Utama</div>
        <ul class="nav-menu">
            <li><a href="dashboard.php" class="active">🏠 Dashboard</a></li>
            <li><a href="anggota.php">👥 Data Anggota</a></li>
            <li><a href="simpanan.php">💰 Input Simpanan</a></li>
            <li><a href="laporan.php">📊 Laporan Simpanan</a></li>
        </ul>

        <div class="menu-label">Akun</div>
        <ul class="nav-menu">
            <li><a href="#">🚪 Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">

        <div class="topbar">
            <div>
                <h2>Input Simpanan</h2>
                <p>Catat simpanan pokok, wajib, dan sukarela anggota koperasi.</p>
            </div>
            <div class="user-pill">Administrator</div>
        </div>

        <div class="row g-4">
            <div class="col-lg-4">
                <div class="content-card">
                    <div class="card-header">
                        <h5>Form Simpanan</h5>
                    </div>

                    <div class="card-body">
                        <form action="#" method="post">
                            <div class="mb-3">
                                <label class="form-label">Tanggal Simpanan</label>
                                <input type="date" class="form-control" value="2026-07-01">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Pilih Anggota</label>
                                <select class="form-select">
                                    <option value="">Pilih anggota koperasi</option>
                                    <option> KOP-2026-001 - Ahmad Fauzi</option>
                                    <option> KOP-2026-002 - Siti Rahmah</option>
                                    <option> KOP-2026-003 - M. Ikhsan</option>
                                    <option> KOP-2026-004 - Nur Aisyah</option>
                                    <option> KOP-2026-005 - Rizky Maulana</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Jenis Simpanan</label>
                                <select class="form-select">
                                    <option value="">Pilih jenis simpanan</option>
                                    <option value="pokok">Simpanan Pokok</option>
                                    <option value="wajib">Simpanan Wajib</option>
                                    <option value="sukarela">Simpanan Sukarela</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Jumlah Simpanan</label>
                                <input type="number" class="form-control" placeholder="Contoh: 100000">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Keterangan</label>
                                <textarea class="form-control" rows="3" placeholder="Keterangan opsional"></textarea>
                            </div>

                            <div class="d-flex gap-2">
                                <button type="reset" class="btn btn-outline-secondary w-50">
                                    Reset
                                </button>
                                <button type="submit" class="btn btn-primary w-50">
                                    Simpan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="content-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Riwayat Simpanan</h5>
                        <span class="badge bg-success rounded-pill">Transaksi Terbaru</span>
                    </div>

                    <div class="card-body">
                        <div class="row g-3 mb-3">
                            <div class="col-md-8">
                                <input type="text" class="form-control" placeholder="Cari nama anggota atau nomor anggota">
                            </div>
                            <div class="col-md-4">
                                <select class="form-select">
                                    <option>Semua Jenis</option>
                                    <option>Pokok</option>
                                    <option>Wajib</option>
                                    <option>Sukarela</option>
                                </select>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Anggota</th>
                                        <th>Jenis</th>
                                        <th>Jumlah</th>
                                        <th>Keterangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>01 Juli 2026</td>
                                        <td>Ahmad Fauzi</td>
                                        <td><span class="badge-soft badge-pokok">Pokok</span></td>
                                        <td class="money">Rp 100.000</td>
                                        <td>Simpanan awal</td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Edit</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger">Hapus</a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>2</td>
                                        <td>01 Juli 2026</td>
                                        <td>Ahmad Fauzi</td>
                                        <td><span class="badge-soft badge-wajib">Wajib</span></td>
                                        <td class="money">Rp 50.000</td>
                                        <td>Bulan Juli</td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Edit</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger">Hapus</a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>3</td>
                                        <td>01 Juli 2026</td>
                                        <td>Siti Rahmah</td>
                                        <td><span class="badge-soft badge-sukarela">Sukarela</span></td>
                                        <td class="money">Rp 150.000</td>
                                        <td>Simpanan tambahan</td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Edit</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger">Hapus</a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>4</td>
                                        <td>01 Juli 2026</td>
                                        <td>M. Ikhsan</td>
                                        <td><span class="badge-soft badge-wajib">Wajib</span></td>
                                        <td class="money">Rp 50.000</td>
                                        <td>Bulan Juli</td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Edit</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger">Hapus</a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </main>

</div>

</body>
</html>