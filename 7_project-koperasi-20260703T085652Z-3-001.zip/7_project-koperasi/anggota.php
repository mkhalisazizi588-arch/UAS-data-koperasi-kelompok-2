<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Anggota | Sistem Koperasi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="app-layout">

    <aside class="sidebar">
        <div class="logo">
            <div class="logo-box">K</div>
            <div>
                <h4>KoperasiApp</h4>
                <small>Panel Administrator</small>
            </div>
        </div>

        <div class="menu-label">Menu Utama</div>
        <ul class="nav-menu">
            <li><a href="dashboard.php" class="active">🏠 Dashboard</a></li>
            <li><a href="anggota.php">👥 Data Anggota</a></li>
            <li><a href="simpanan.php">💰 Input Simpanan</a></li>
            <li><a href="laporan.php">📊 Laporan Simpanan</a></li>
        </ul>

        <div class="menu-label">Akun</div>
        <ul class="nav-menu">
            <li><a href="#">🚪 Logout</a></li>
        </ul>
    </aside>

    <main class="main-content">

        <div class="topbar">
            <div>
                <h2>Data Anggota</h2>
                <p>Kelola data anggota koperasi secara rapi dan terstruktur.</p>
            </div>
            <div class="user-pill">Administrator</div>
        </div>

        <div class="row g-4">
            <div class="col-lg-4">
                <div class="content-card">
                    <div class="card-header">
                        <h5>Tambah Anggota</h5>
                    </div>

                    <div class="card-body">
                        <form action="#" method="post">
                            <div class="mb-3">
                                <label class="form-label">Nomor Anggota</label>
                                <input type="text" class="form-control" placeholder="Contoh: KOP-2026-001">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Nama Anggota</label>
                                <input type="text" class="form-control" placeholder="Masukkan nama lengkap">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Jenis Kelamin</label>
                                <select class="form-select">
                                    <option value="">Pilih jenis kelamin</option>
                                    <option value="L">Laki-laki</option>
                                    <option value="P">Perempuan</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Tempat Lahir</label>
                                <input type="text" class="form-control" placeholder="Contoh: Banda Aceh">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Tanggal Lahir</label>
                                <input type="date" class="form-control">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">No. HP</label>
                                <input type="text" class="form-control" placeholder="Contoh: 081234567890">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Pekerjaan</label>
                                <input type="text" class="form-control" placeholder="Contoh: Wiraswasta">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Alamat</label>
                                <textarea class="form-control" rows="3" placeholder="Masukkan alamat lengkap"></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Tanggal Daftar</label>
                                <input type="date" class="form-control">
                            </div>

                            <button type="submit" class="btn btn-primary w-100">
                                Simpan Anggota
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="content-card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Daftar Anggota</h5>
                        <span class="badge bg-success rounded-pill">125 Anggota</span>
                    </div>

                    <div class="card-body">
                        <div class="row g-3 mb-3">
                            <div class="col-md-8">
                                <input type="text" class="form-control" placeholder="Cari nama, nomor anggota, atau no. HP">
                            </div>
                            <div class="col-md-4">
                                <select class="form-select">
                                    <option>Semua Status</option>
                                    <option>Aktif</option>
                                    <option>Nonaktif</option>
                                </select>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>No. Anggota</th>
                                        <th>Nama</th>
                                        <th>JK</th>
                                        <th>No. HP</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>KOP-2026-001</td>
                                        <td>Ahmad Fauzi</td>
                                        <td>L</td>
                                        <td>081234567001</td>
                                        <td><span class="badge-soft badge-aktif">Aktif</span></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Edit</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger">Hapus</a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>2</td>
                                        <td>KOP-2026-002</td>
                                        <td>Siti Rahmah</td>
                                        <td>P</td>
                                        <td>081234567002</td>
                                        <td><span class="badge-soft badge-aktif">Aktif</span></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Edit</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger">Hapus</a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>3</td>
                                        <td>KOP-2026-003</td>
                                        <td>M. Ikhsan</td>
                                        <td>L</td>
                                        <td>081234567003</td>
                                        <td><span class="badge-soft badge-aktif">Aktif</span></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Edit</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger">Hapus</a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>4</td>
                                        <td>KOP-2026-004</td>
                                        <td>Nur Aisyah</td>
                                        <td>P</td>
                                        <td>081234567004</td>
                                        <td><span class="badge-soft badge-aktif">Aktif</span></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Edit</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger">Hapus</a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>5</td>
                                        <td>KOP-2026-005</td>
                                        <td>Rizky Maulana</td>
                                        <td>L</td>
                                        <td>081234567005</td>
                                        <td><span class="badge-soft badge-nonaktif">Nonaktif</span></td>
                                        <td>
                                            <a href="#" class="btn btn-sm btn-outline-primary">Edit</a>
                                            <a href="#" class="btn btn-sm btn-outline-danger">Hapus</a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </main>

</div>

</body>
</html>